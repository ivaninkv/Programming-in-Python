def calc_age(uid):
    pass


if __name__ == '__main__':
    res = calc_age('reigning')
    print(res)
